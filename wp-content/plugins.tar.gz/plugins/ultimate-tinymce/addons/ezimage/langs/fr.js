// Easy Image plugin 1.0 (c) FFh Lab / Eric Lequien for TinyMCE 3.x+ (c) Moxiecode Systems AB

tinyMCE.addI18n('fr.ezimage',{
	desc : 'Ins�rer / �diter une image'
});