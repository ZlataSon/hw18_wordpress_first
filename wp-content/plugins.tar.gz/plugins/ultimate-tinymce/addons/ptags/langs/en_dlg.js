tinyMCE.addI18n('en.ptags_dlg',{
	
    titleP : "Insert P Tag",
	noteP : 'You have selected the <strong>p</strong> tag. Your tag may be refined using the options below.<br /><br />Click "Insert" to insert selection.<br /><br /><br />',
	jwlid : "Enter ID for p tag",
	jwlclass : "Enter CLASSES for p tag",
	jwlstyle : "Enter Style Attributes",
	noteP2 : "(Optional)"
	
});